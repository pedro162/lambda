def log(mensagem):
    print('Adicionando log: ', mensagem)  